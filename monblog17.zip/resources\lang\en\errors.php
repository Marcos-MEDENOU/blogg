<?php

return [

    'error-404' => 'Error 404',
    'error-404-info' => 'This page doesn\'t exist !',
    'error-403' => 'Error 403',
    'error-403-info' => 'This action is unauthorized.',
    'error-503' => 'Error 503',
    'error-503-info' => 'Be right back.',

];
