<?php $attributes = $attributes->exceptProps([
  'type',
  'number',
  'title',
  'route',
  'model',
]); ?>
<?php foreach (array_filter(([
  'type',
  'number',
  'title',
  'route',
  'model',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="col-lg-3 col-6">
  <div class="small-box bg-<?php echo e($type); ?>">
    <div class="inner">
      <h3><?php echo e($number); ?></h3>
      <p><?php echo app('translator')->get($title); ?></p>
    </div>
    <div class="icon">
      <i class="ion ion-bag"></i>
    </div>
    <a href="<?php echo e(route($route)); ?>" class="small-box-footer"><?php echo app('translator')->get('More info'); ?> <i class="fas fa-arrow-circle-right"></i></a>
    <form action="<?php echo e(route('purge', $model)); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>
      <button type="submit" class="btn btn-<?php echo e($type); ?> btn-block text-warning"><?php echo app('translator')->get('Purge'); ?></button>
    </form>
  </div>
</div><?php /**PATH E:\laragon\www\monblog\resources\views/components/back/box.blade.php ENDPATH**/ ?>