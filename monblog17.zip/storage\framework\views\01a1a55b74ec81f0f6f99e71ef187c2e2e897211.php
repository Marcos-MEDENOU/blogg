<?php $attributes = $attributes->exceptProps(['email' => '']); ?>
<?php foreach (array_filter((['email' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div>
  <label for="email"><?php echo app('translator')->get('Email'); ?></label>  
  <input 
      id="email" 
      class="h-full-width" 
      type="email" 
      name="email" 
      placeholder="<?php echo app('translator')->get('Your email'); ?>" 
      value="<?php echo e(old('email', $email)); ?>" 
      required 
      autofocus>
</div><?php /**PATH E:\laragon\www\monblog\resources\views/components/auth/input-email.blade.php ENDPATH**/ ?>