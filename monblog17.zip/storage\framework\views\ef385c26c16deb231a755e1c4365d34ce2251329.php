<?php $attributes = $attributes->exceptProps([
    'type', 
    'icon' => 'check', 
    'title' => '',
]); ?>
<?php foreach (array_filter(([
    'type', 
    'icon' => 'check', 
    'title' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="alert alert-<?php echo e($type); ?> alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <h5><span class="icon fa fa-<?php echo e($icon); ?>"></span><?php echo e($title); ?></h5>
    <?php echo e($slot); ?>

</div><?php /**PATH E:\laragon\www\monblog\resources\views/components/back/alert.blade.php ENDPATH**/ ?>