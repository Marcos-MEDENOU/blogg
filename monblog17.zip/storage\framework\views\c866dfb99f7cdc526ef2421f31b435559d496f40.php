<?php $attributes = $attributes->exceptProps([
    'outline' => true, 
    'type', 
    'title', 
]); ?>
<?php foreach (array_filter(([
    'outline' => true, 
    'type', 
    'title', 
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="card <?php if($outline): ?> card-outline <?php endif; ?> card-<?php echo e($type); ?>">
    <?php if($title): ?>
      <div class="card-header">
          <h3 class="card-title"><?php echo e(__($title)); ?></h3>
          <div class="card-tools pull-right">
              <button 
                  type="button" 
                  class="btn btn-tool" 
                  data-card-widget="collapse">
                  <i class="fas fa-minus"></i>
              </button>
          </div>
      </div>
    <?php endif; ?>
    <div class="card-body">
        <?php echo e($slot); ?>

    </div>
</div><?php /**PATH E:\laragon\www\monblog\resources\views/components/back/card.blade.php ENDPATH**/ ?>