<div>
    <label for="password"><?php echo app('translator')->get('Password'); ?></label> 
    <input 
        id="password" 
        class="h-full-width" 
        type="password" 
        name="password" 
        placeholder="<?php echo app('translator')->get('Your password'); ?>" 
        required>
</div><?php /**PATH E:\laragon\www\monblog\resources\views/components/auth/input-password.blade.php ENDPATH**/ ?>