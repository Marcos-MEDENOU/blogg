@props(['title'])

<input class="btn--primary h-full-width" type="submit" value="@lang($title)">