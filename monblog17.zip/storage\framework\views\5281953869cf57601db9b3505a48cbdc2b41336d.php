<?php $attributes = $attributes->exceptProps([
    'input', 
    'name', 
    'required' => false, 
    'title',
    'rows' => 3, 
    'title', 
    'label', 
    'options', 
    'value' => '', 
    'Values',
    'multiple' => false,
]); ?>
<?php foreach (array_filter(([
    'input', 
    'name', 
    'required' => false, 
    'title',
    'rows' => 3, 
    'title', 
    'label', 
    'options', 
    'value' => '', 
    'Values',
    'multiple' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="form-group">

    <?php if(isset($title)): ?>
        <label for="<?php echo e($name); ?>"><?php echo app('translator')->get($title); ?></label>
    <?php endif; ?>

    <?php if($input === 'textarea'): ?>
        <textarea 
            class="form-control<?php echo e($errors->has($name) ? ' is-invalid' : ''); ?>" 
            rows="<?php echo e($rows); ?>" 
            id="<?php echo e($name); ?>" 
            name="<?php echo e($name); ?>" 
            <?php if($required): ?> required <?php endif; ?>><?php echo e(old($name, $value)); ?></textarea>
   
    <?php elseif($input === 'checkbox'): ?>
        <div class="custom-control custom-checkbox">
            <input 
                class="custom-control-input" 
                id="<?php echo e($name); ?>" 
                name="<?php echo e($name); ?>" 
                type="checkbox" 
                <?php echo e($value ? 'checked' : ''); ?>>
            <label 
                class="custom-control-label" 
                for="<?php echo e($name); ?>">
                <?php echo e(__($label)); ?>

            </label>
        </div>

      <?php elseif($input === 'select'): ?>
        <select 
            <?php if($required): ?> required <?php endif; ?> 
            class="form-control<?php echo e($errors->has($name) ? ' is-invalid' : ''); ?>" 
            name="<?php echo e($name); ?>" 
            id="<?php echo e($name); ?>">
            <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option 
                    value="<?php echo e($option); ?>"
                    <?php echo e(old($name) ? (old($name) == $option ? 'selected' : '') : ($option == $value ? 'selected' : '')); ?>>
                    <?php echo e($option); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

    <?php elseif($input === 'selectMultiple'): ?>
        <select 
            multiple
            <?php if($required): ?> required <?php endif; ?> 
            class="form-control<?php echo e($errors->has($name) ? ' is-invalid' : ''); ?>" 
            name="<?php echo e($name); ?>[]" 
            id="<?php echo e($name); ?>">
            <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option 
                    value="<?php echo e($id); ?>" 
                    <?php echo e(old($name) ? (in_array($id, old($name)) ? 'selected' : '') : ($values->contains('id', $id) ? 'selected' : '')); ?>>
                    <?php echo e($title); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
   
    <?php else: ?>
        <input 
            type="text" 
            class="form-control<?php echo e($errors->has($name) ? ' is-invalid' : ''); ?>" 
            id="<?php echo e($name); ?>" 
            name="<?php echo e($name); ?>" 
            value="<?php echo e(old($name, $value)); ?>" 
            <?php if($required): ?> required <?php endif; ?>>
    
    <?php endif; ?>

    <?php if($errors->has($name)): ?>
        <div class="invalid-feedback">
            <?php echo e($errors->first($name)); ?>

        </div>
    <?php endif; ?>
    
</div>

<?php /**PATH E:\laragon\www\monblog\resources\views/components/back/input.blade.php ENDPATH**/ ?>