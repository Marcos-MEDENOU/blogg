

<?php $__env->startSection('main'); ?>

    <!-- content
    ================================================== -->
    <div class="row">
        <div class="column large-12">

          <article class="s-content__entry">

            <div class="s-content__entry-header">
                <h1 class="s-content__title"><?php echo app('translator')->get($page->title); ?></h1>
            </div>

            <div class="s-content__primary">

                <div class="s-content__page-content">

                    <?php echo $page->body; ?>


                </div>

            </div>
        </article>

        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\monblog\resources\views/front/page.blade.php ENDPATH**/ ?>