<div>
    <label for="password">@lang('Password')</label> 
    <input 
        id="password" 
        class="h-full-width" 
        type="password" 
        name="password" 
        placeholder="@lang('Your password')" 
        required>
</div>