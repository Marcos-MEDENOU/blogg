<?php $attributes = $attributes->exceptProps(['post']); ?>
<?php foreach (array_filter((['post']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="s-hero__slide">

  <div class="s-hero__slide-bg" style="background-image: url('storage/photos/<?php echo e($post->user->id); ?>/<?php echo e($post->image); ?>')"></div>

  <div class="row s-hero__slide-content animate-this">
      <div class="column">
          <div class="s-hero__slide-meta">
              <span class="cat-links">
                  <?php $__currentLoopData = $post->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <a href="#"><?php echo e($category->title); ?></a>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </span>
              <span class="byline"> 
                  <?php echo app('translator')->get('Posted By'); ?> 
                  <span class="author">
                      <a href="#"><?php echo e($post->user->name); ?></a>
                  </span>
              </span>
          </div>
          <h1 class="s-hero__slide-text">
              <a href="#"><?php echo e($post->title); ?></a>
          </h1>
      </div>
  </div>

</div><?php /**PATH E:\laragon\www\monblog\resources\views/components/front/hero.blade.php ENDPATH**/ ?>