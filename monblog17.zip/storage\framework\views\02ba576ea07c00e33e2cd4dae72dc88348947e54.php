 

<?php $__env->startSection('main'); ?> 
  <div class="container-fluid">
      <div class="row">

        <?php if($posts): ?>
          <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.back.box','data' => ['type' => 'info','number' => $posts,'title' => 'New posts','route' => 'posts.indexnew','model' => 'post']]); ?>
<?php $component->withName('back.box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'info','number' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($posts),'title' => 'New posts','route' => 'posts.indexnew','model' => 'post']); ?>
           <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php endif; ?>

        <?php if($users): ?>
          <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.back.box','data' => ['type' => 'success','number' => $users,'title' => 'New users','route' => 'users.indexnew','model' => 'user']]); ?>
<?php $component->withName('back.box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'success','number' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($users),'title' => 'New users','route' => 'users.indexnew','model' => 'user']); ?>
           <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php endif; ?>

        <?php if($contacts): ?>
          <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.back.box','data' => ['type' => 'primary','number' => $contacts,'title' => 'New contacts','route' => 'contacts.indexnew','model' => 'contact']]); ?>
<?php $component->withName('back.box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'primary','number' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($contacts),'title' => 'New contacts','route' => 'contacts.indexnew','model' => 'contact']); ?>
           <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php endif; ?>

        <?php if($comments): ?>
          <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.back.box','data' => ['type' => 'danger','number' => $comments,'title' => 'New comments','route' => 'comments.indexnew','model' => 'comment']]); ?>
<?php $component->withName('back.box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'danger','number' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($comments),'title' => 'New comments','route' => 'comments.indexnew','model' => 'comment']); ?>
           <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php endif; ?> 

      </div>      
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\monblog\resources\views/back/index.blade.php ENDPATH**/ ?>