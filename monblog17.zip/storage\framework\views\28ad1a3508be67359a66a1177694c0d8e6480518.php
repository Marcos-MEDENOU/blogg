<?php $attributes = $attributes->exceptProps(['post']); ?>
<?php foreach (array_filter((['post']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<article class="brick entry" data-aos="fade-up">

  <div class="entry__thumb">
      <a href="<?php echo e(route('posts.display', $post->slug)); ?>" class="thumb-link">
          <img src="<?php echo e(getImage($post, true)); ?>" alt="" style="width:100%">
      </a>
  </div>

  <div class="entry__text">
      <div class="entry__header">
          <h1 class="entry__title"><a href="<?php echo e(route('posts.display', $post->slug)); ?>"><?php echo e($post->title); ?></a></h1>          
          <div class="entry__meta">
              <span class="byline""><?php echo app('translator')->get('By:'); ?>
                  <span class='author'>
                      <a href="<?php echo e(route('author', $post->user->id)); ?>"><?php echo e($post->user->name); ?></a>
                  </span>
              </span>
          </div>
      </div>
      <div class="entry__excerpt">
          <p><?php echo e($post->excerpt); ?></p>
      </div>
      <a class="entry__more-link" href="<?php echo e(route('posts.display', $post->slug)); ?>"><?php echo app('translator')->get('Read More'); ?></a>
  </div>

</article><?php /**PATH E:\laragon\www\monblog\resources\views/components/front/brick.blade.php ENDPATH**/ ?>