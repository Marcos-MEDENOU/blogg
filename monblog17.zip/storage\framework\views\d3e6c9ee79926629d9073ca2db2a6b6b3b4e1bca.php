<?php if($paginator->hasPages()): ?>
    <nav class="pgn">
        <ul>
            
            <li>
                <?php if($paginator->onFirstPage()): ?>
                    <span class="pgn__prev inactive" href="#0"><?php echo app('translator')->get('Prev'); ?></span>
                <?php else: ?>
                    <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="pgn__prev" rel="prev"><?php echo app('translator')->get('Prev'); ?></a>
                <?php endif; ?>
            </li>

            
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                
                <?php if(is_string($element)): ?>
                    <li><span class="pgn__num current"><?php echo e($element); ?></span></li>
                <?php endif; ?>

                
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <?php if($page == $paginator->currentPage()): ?>
                                <span class="pgn__num current"><?php echo e($page); ?></span>
                            <?php else: ?>
                                <a href="<?php echo e($url); ?>" class="pgn__num"><?php echo e($page); ?></a>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <li>
                <?php if($paginator->hasMorePages()): ?>
                    <a href="<?php echo e($paginator->nextPageUrl()); ?>"  class="pgn__next" rel="next"><?php echo app('translator')->get('Next'); ?></a>
                <?php else: ?>
                    <span class="pgn__next inactive"><?php echo app('translator')->get('Next'); ?></span>
                <?php endif; ?>
            </li>
        </ul>
    </nav>
<?php endif; ?>
<?php /**PATH E:\laragon\www\monblog\resources\views/front/pagination.blade.php ENDPATH**/ ?>