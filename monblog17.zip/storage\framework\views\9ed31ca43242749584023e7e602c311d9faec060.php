<?php $attributes = $attributes->exceptProps(['status']); ?>
<?php foreach (array_filter((['status']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php if($status): ?>
    <div class="alert-box alert-box--info">
        <p><?php echo e($status); ?></p>
        <span class="alert-box__close"></span>
    </div>
<?php endif; ?>
<?php /**PATH E:\laragon\www\monblog\resources\views/components/auth/session-status.blade.php ENDPATH**/ ?>